﻿namespace FinalTestAssignment
{
    internal interface ITestService
    {
    }
}